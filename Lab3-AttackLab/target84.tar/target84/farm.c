/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_174(unsigned x)
{
    return x + 2425393240U;
}

unsigned getval_396()
{
    return 2421179065U;
}

void setval_264(unsigned *p)
{
    *p = 3284633928U;
}

void setval_164(unsigned *p)
{
    *p = 2462550344U;
}

unsigned addval_138(unsigned x)
{
    return x + 3284633928U;
}

void setval_473(unsigned *p)
{
    *p = 3347646634U;
}

unsigned addval_201(unsigned x)
{
    return x + 2417503835U;
}

unsigned getval_330()
{
    return 2425393240U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_403(unsigned x)
{
    return x + 3286272360U;
}

void setval_309(unsigned *p)
{
    *p = 3223376265U;
}

unsigned getval_107()
{
    return 2425406089U;
}

unsigned addval_313(unsigned x)
{
    return x + 2430635336U;
}

void setval_155(unsigned *p)
{
    *p = 3375940235U;
}

unsigned addval_357(unsigned x)
{
    return x + 2430634312U;
}

unsigned addval_437(unsigned x)
{
    return x + 3675832969U;
}

unsigned getval_460()
{
    return 3348156041U;
}

void setval_190(unsigned *p)
{
    *p = 3224424073U;
}

unsigned addval_334(unsigned x)
{
    return x + 3286272344U;
}

unsigned addval_461(unsigned x)
{
    return x + 2464188744U;
}

unsigned getval_222()
{
    return 3234120329U;
}

unsigned getval_220()
{
    return 2425409161U;
}

unsigned getval_436()
{
    return 3281047177U;
}

unsigned addval_170(unsigned x)
{
    return x + 3281044107U;
}

void setval_426(unsigned *p)
{
    *p = 3286272328U;
}

void setval_270(unsigned *p)
{
    *p = 3526939033U;
}

void setval_200(unsigned *p)
{
    *p = 2425668233U;
}

unsigned addval_361(unsigned x)
{
    return x + 3524841097U;
}

void setval_410(unsigned *p)
{
    *p = 3531919757U;
}

unsigned addval_128(unsigned x)
{
    return x + 3222851209U;
}

void setval_472(unsigned *p)
{
    *p = 3223896713U;
}

void setval_491(unsigned *p)
{
    *p = 3223900553U;
}

void setval_298(unsigned *p)
{
    *p = 3286273352U;
}

unsigned addval_433(unsigned x)
{
    return x + 2463009272U;
}

void setval_195(unsigned *p)
{
    *p = 3281044105U;
}

unsigned getval_335()
{
    return 3374371213U;
}

unsigned addval_232(unsigned x)
{
    return x + 3525890441U;
}

unsigned addval_360(unsigned x)
{
    return x + 3286272320U;
}

unsigned getval_297()
{
    return 3677933185U;
}

unsigned getval_181()
{
    return 2425409929U;
}

void setval_444(unsigned *p)
{
    *p = 3223376281U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
